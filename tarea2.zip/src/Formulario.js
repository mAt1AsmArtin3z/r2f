import './Formulario.css';

function Formulario () {
    return(
        <div className='contenedorw'>
            <form>
                <label>nombre</label>
                <input type='text' required></input>
                <label>email</label>
                <input type='email' required></input>
                <label>contraseña</label>
                <input type='password' required></input>
                <button type='submit'>enviar</button>
                <h3>trabajo incompleto</h3>
            </form>
        </div>
    );

}
export default Formulario;