import './Notas.css';
import React, { useState, useEffect, useCallback } from 'react';

//ver luego
// Función para simular el guardado en una base de datos o almacenamiento local
const saveNote = (content) => {
  console.log('Nota guardada:', content);
  // Aquí podrías hacer una llamada a una API para guardar el contenido
  // Ejemplo: fetch('/api/save-note', { method: 'POST', body: JSON.stringify({ content }) });
};

function Notas() {
  const [note, setNote] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  
  // Temporizador de guardado automático
  const [saveTimeout, setSaveTimeout] = useState(null);

  const handleChange = (event) => {
    setNote(event.target.value);

    // Si hay un temporizador de guardado anterior, lo limpiamos
    if (saveTimeout) {
      clearTimeout(saveTimeout);
    }

    // Configuramos un nuevo temporizador de guardado
    const newTimeout = setTimeout(() => {
      setIsSaving(true);
      saveNote(event.target.value);
      setIsSaving(false);
    }, 2000); // 2000 ms = 2 segundos

    setSaveTimeout(newTimeout);
  };

  // Cleanup en caso de que el componente se desmonte
  useEffect(() => {
    return () => {
      if (saveTimeout) {
        clearTimeout(saveTimeout);
      }
    };
  }, [saveTimeout]);

  return (
    <div className="App">
      <h1>Aplicación de Notas</h1>
      <textarea
        value={note}
        onChange={handleChange}
        placeholder="Escribe tu nota aquí..."
        rows="10"
        cols="30"
      />
      {isSaving && <p>Guardando...</p>}
      <h3>este ejercicio fue realizado con chatgpt por falta de tiempo, revisar al llegar</h3>
    </div>
    
  );
}

export default Notas;